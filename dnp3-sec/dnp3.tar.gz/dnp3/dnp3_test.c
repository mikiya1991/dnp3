#include <stdio.h>
#include <string.h>
#include "dnp3_sec.h"

enum HMAC_FUN {SHA1,SHA256,AESGMAC};
void pt(uchar* s,size_t len){
	uchar* p = s;
	int i;
	for(i=0;i<len;i++) printf("%2x",*p++);
	printf("\n");
}
int main(){
	uchar sessionkey[16];
	memcpy(sessionkey,"iamtestsessionkeyfordnp3security",16);
	int protocol=0;
	switch(protocol){
	case SHA1:
		{
			printf("sessionkey: ");
			pt(sessionkey,16);
			uchar chan[CHA_SHA1_SIZE];
			challenge_sha1(sessionkey,16,chan);
			printf("challenge content: ");
			pt(chan,CHA_SHA1_SIZE);
			uchar hash[HMAC_SHA1_SERIAL_SIZE];
			hmac_sha1_serial(chan,CHA_SHA1_SIZE,sessionkey,16,hash);
			printf("challenge hash: ");
			pt(hash,HMAC_SHA1_SERIAL_SIZE);
			int res = auth_sha1_serial(chan,16,sessionkey,16,hash);
			printf("auth result: %d\n",res);
		}
		break;
	case SHA256:
		break;
	}
	return 0;		
}
